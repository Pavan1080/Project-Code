Primary_NAR = Primary education net attendance ratio
Primary_NER = Primary education net enrolment rate
ALR         = Adul literacy rate